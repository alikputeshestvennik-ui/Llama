package com.blackbox.offline;

import android.content.*;
import android.net.Uri;
import java.io.*;

/** Copies user-selected offline model files into app-private storage. No network access. */
public final class ModelManager {
 public static final String WHISPER="whisper.bin", LLM="qwen.gguf", SOUNDS="sound-classifier.tflite";
 private ModelManager(){}
 public static File folder(Context c){File f=new File(c.getExternalFilesDir(null),"models");if(!f.exists())f.mkdirs();return f;}
 public static File file(Context c,String name){return new File(folder(c),name);}
 public static boolean installed(Context c,String name){return file(c,name).isFile()&&file(c,name).length()>1024;}
 public static void importFile(Context c,Uri uri,String destination)throws IOException{
  File out=file(c,destination);File temp=new File(out.getAbsolutePath()+".part");
  try(InputStream in=c.getContentResolver().openInputStream(uri);OutputStream os=new FileOutputStream(temp)){
   if(in==null)throw new IOException("Файл недоступен");byte[] b=new byte[1024*128];int n;while((n=in.read(b))!=-1)os.write(b,0,n);
  }
  if(out.exists())out.delete();if(!temp.renameTo(out))throw new IOException("Не удалось сохранить файл");
 }
 public static String size(Context c,String name){File f=file(c,name);if(!f.exists())return "не установлена";return String.format(java.util.Locale.getDefault(),"установлена · %.1f МБ",f.length()/1048576.0);}
}
