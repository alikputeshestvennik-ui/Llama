package com.blackbox.offline;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

/**
 * Decodes recordings to mono 16 kHz float PCM for whisper.cpp.
 * Primary path: Blackbox writes its own PCM WAV (RIFF/16-bit/mono) — decoded
 * directly, without MediaCodec (which many devices refuse for raw PCM WAV).
 * Fallback: AAC/M4A/AMR via MediaExtractor + MediaCodec.
 */
final class PcmDecoder {
 private PcmDecoder() {}

 static float[] decode16kMono(String path) throws Exception {
  if (path == null) throw new IllegalArgumentException("Пустой путь к записи");
  File f = new File(path);
  if (!f.isFile() || f.length() < 64) throw new IllegalStateException("Файл записи повреждён или пуст");

  if (path.toLowerCase().endsWith(".wav")) {
   float[] w = decodePcmWav(f);
   if (w != null && w.length > 3200) { // > 0.2 s — файл наш, декодирован нормально
    return trimSilence(w, 1600);
   }
   // Иначе — WAV чужого формата, попробуем системный декодер ниже
  }
  return trimSilence(decodeWithMediaCodec(path), 1600);
 }

 /** Читает PCM WAV (16 бит, PCM, RIFF), ресемплирует в 16 кГц моно. */
 private static float[] decodePcmWav(File f) throws Exception {
  byte[] raw;
  try (FileInputStream in = new FileInputStream(f)) {
   raw = new byte[(int) f.length()];
   int off = 0;
   while (off < raw.length) {
    int n = in.read(raw, off, raw.length - off);
    if (n < 0) break;
    off += n;
   }
   if (off < raw.length) {
    byte[] t = new byte[off];
    System.arraycopy(raw, 0, t, 0, off);
    raw = t;
   }
  }
  if (raw.length < 44) return null;

  // Разбор RIFF-чанков (fmt/data). Работает и с нестандартным порядком чанков.
  int rate = 0, channels = 1, bits = 16, format = 1;
  int dataOff = -1, dataLen = 0;
  int pos = 12; // после RIFF....WAVE
  while (pos + 8 <= raw.length) {
   String id = new String(raw, pos, 4, "US-ASCII");
   int size = (raw[pos + 4] & 255) | ((raw[pos + 5] & 255) << 8) | ((raw[pos + 6] & 255) << 16) | ((raw[pos + 7] & 255) << 24);
   if (size < 0) break;
   int body = pos + 8;
   if ("fmt ".equals(id) && body + 16 <= raw.length) {
    format = (raw[body] & 255) | ((raw[body + 1] & 255) << 8);
    channels = (raw[body + 2] & 255) | ((raw[body + 3] & 255) << 8);
    rate = (raw[body + 4] & 255) | ((raw[body + 5] & 255) << 8) | ((raw[body + 6] & 255) << 16) | ((raw[body + 7] & 255) << 24);
    bits = (raw[body + 14] & 255) | ((raw[body + 15] & 255) << 8);
   } else if ("data".equals(id)) {
    dataOff = body;
    dataLen = Math.min(size, raw.length - body);
   }
   pos = body + size + (size & 1); // чанки выровнены на 2 байта
  }
  if (dataOff < 0 || rate <= 0) return null;
  if (format != 1 || bits != 16 || channels < 1) return null; // не PCM16 — дальше MediaCodec

  int frameBytes = 2 * channels;
  int frames = dataLen / frameBytes;
  if (frames <= 0) return null;

  float[] mono = new float[frames];
  for (int i = 0; i < frames; i++) {
   int base = dataOff + i * frameBytes;
   long acc = 0;
   for (int c = 0; c < channels; c++) {
    int lo = raw[base + c * 2] & 255, hi = raw[base + c * 2 + 1];
    acc += (short) (lo | (hi << 8));
   }
   mono[i] = (float) (acc / (32768.0 * channels));
  }
  return resample(mono, rate, 16000);
 }

 private static float[] decodeWithMediaCodec(String path) throws Exception {
  MediaExtractor ex = new MediaExtractor(); ex.setDataSource(path); int track = -1;
  for (int i = 0; i < ex.getTrackCount(); i++) { MediaFormat f = ex.getTrackFormat(i); String mime = f.getString(MediaFormat.KEY_MIME); if (mime != null && mime.startsWith("audio/")) { track = i; break; } }
  if (track < 0) throw new IllegalArgumentException("В записи нет аудиодорожки");
  ex.selectTrack(track); MediaFormat in = ex.getTrackFormat(track); String mime = in.getString(MediaFormat.KEY_MIME);
  MediaCodec codec = MediaCodec.createDecoderByType(mime); codec.configure(in, null, null, 0); codec.start();
  int srcRate = in.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? in.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
  int srcChannels = in.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? in.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;
  ArrayList<Float> mono = new ArrayList<>(); MediaCodec.BufferInfo info = new MediaCodec.BufferInfo(); boolean inputDone = false, outputDone = false;
  while (!outputDone) {
   if (!inputDone) { int idx = codec.dequeueInputBuffer(10000); if (idx >= 0) { ByteBuffer b = codec.getInputBuffer(idx); int n = ex.readSampleData(b, 0); if (n < 0) { codec.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true; } else { codec.queueInputBuffer(idx, 0, n, ex.getSampleTime(), 0); ex.advance(); } } }
   int out = codec.dequeueOutputBuffer(info, 10000); if (out >= 0) { ByteBuffer b = codec.getOutputBuffer(out); if (b != null && info.size > 0) { b.position(info.offset); b.limit(info.offset + info.size); b.order(ByteOrder.LITTLE_ENDIAN); while (b.remaining() >= 2) { float total = 0; int got = 0; for (int c = 0; c < srcChannels && b.remaining() >= 2; c++) { total += b.getShort() / 32768f; got++; } if (got > 0) mono.add(total / got); } } codec.releaseOutputBuffer(out, false); if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true; }
  }
  codec.stop(); codec.release(); ex.release(); if (mono.isEmpty()) throw new IllegalStateException("Не удалось декодировать аудио");
  float[] m = new float[mono.size()];
  for (int i = 0; i < m.length; i++) m[i] = mono.get(i);
  return resample(m, srcRate, 16000);
 }

 private static float[] resample(float[] in, int from, int to) {
  if (from == to) return in;
  int outLen = (int) ((long) in.length * to / from);
  float[] out = new float[outLen];
  for (int i = 0; i < outLen; i++) {
   double p = (double) i * from / to; int a = (int) p, b = Math.min(a + 1, in.length - 1); double k = p - a;
   out[i] = (float) (in[a] * (1 - k) + in[b] * k);
  }
  return out;
 }

 /** Обрезает начальную/конечную тишину, чтобы whisper не фантазировал на шорохах. */
 private static float[] trimSilence(float[] x, int window) {
  if (x == null || x.length < window * 4) return x;
  float peak = 0;
  for (float v : x) { float a = v < 0 ? -v : v; if (a > peak) peak = a; }
  if (peak < 0.01f) return x;
  double thr = peak * 0.06;
  int s = 0;
  for (int i = 0; i + window <= x.length; i += window) {
   double sum = 0; for (int j = i; j < i + window; j++) { float a = x[j] < 0 ? -x[j] : x[j]; sum += a * a; }
   if (Math.sqrt(sum / window) > thr) { s = Math.max(0, i - window); break; }
  }
  int e2 = x.length;
  for (int i = x.length - window; i >= s; i -= window) {
   double sum = 0; for (int j = i; j < i + window; j++) { float a = x[j] < 0 ? -x[j] : x[j]; sum += a * a; }
   if (Math.sqrt(sum / window) > thr) { e2 = Math.min(x.length, i + window * 2); break; }
  }
  if (e2 - s < window * 4) return x;
  float[] out = new float[e2 - s];
  System.arraycopy(x, s, out, 0, out.length);
  return out;
 }
}