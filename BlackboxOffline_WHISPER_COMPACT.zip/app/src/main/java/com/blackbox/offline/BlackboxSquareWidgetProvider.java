package com.blackbox.offline;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.View;
import android.widget.RemoteViews;

/**
 * Minimalist 1x1 Square Transparent Widget.
 * Shows monochrome logo when inactive, vibrant glowing logo + rec dot when active.
 * Clicking directly on the icon toggles background recording.
 */
public class BlackboxSquareWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_TOGGLE = "com.blackbox.offline.SQUARE_WIDGET_TOGGLE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        boolean isActive = RecordingService.isRecordingActive;
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId, isActive);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent != null ? intent.getAction() : "";

        if (ACTION_TOGGLE.equals(action)) {
            boolean active = RecordingService.isRecordingActive;
            Intent serviceIntent = new Intent(context, RecordingService.class);
            if (active) {
                serviceIntent.setAction(RecordingService.STOP);
                context.startService(serviceIntent);
                updateAllSquareWidgets(context, false);
            } else {
                serviceIntent.setAction(RecordingService.START);
                if (Build.VERSION.SDK_INT >= 26) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
                updateAllSquareWidgets(context, true);
            }
        } else if (RecordingService.STATE.equals(action)) {
            boolean active = intent.getBooleanExtra("active", false);
            updateAllSquareWidgets(context, active);
        }
    }

    public static void updateAllSquareWidgets(Context context, boolean isActive) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            ComponentName widgetName = new ComponentName(context, BlackboxSquareWidgetProvider.class);
            int[] ids = manager.getAppWidgetIds(widgetName);
            if (ids != null && ids.length > 0) {
                for (int id : ids) {
                    updateWidget(context, manager, id, isActive);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int widgetId, boolean isActive) {
        String pkg = context.getPackageName();
        int layoutId = context.getResources().getIdentifier("widget_blackbox_square", "layout", pkg);
        if (layoutId == 0) return;

        RemoteViews views = new RemoteViews(pkg, layoutId);

        int rootId = context.getResources().getIdentifier("widget_square_root", "id", pkg);
        int logoId = context.getResources().getIdentifier("widget_square_logo", "id", pkg);
        int dotId = context.getResources().getIdentifier("widget_square_dot", "id", pkg);

        int logoColorRes = context.getResources().getIdentifier("blackbox_mark", "drawable", pkg);
        int logoMonoRes = context.getResources().getIdentifier("blackbox_mark_mono", "drawable", pkg);

        Intent toggleIntent = new Intent(context, BlackboxSquareWidgetProvider.class).setAction(ACTION_TOGGLE);
        PendingIntent togglePi = PendingIntent.getBroadcast(
                context,
                2,
                toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        if (rootId != 0) views.setOnClickPendingIntent(rootId, togglePi);
        if (logoId != 0) views.setOnClickPendingIntent(logoId, togglePi);

        if (logoId != 0) {
            views.setImageViewResource(logoId, isActive ? logoColorRes : logoMonoRes);
        }

        if (dotId != 0) {
            views.setViewVisibility(dotId, isActive ? View.VISIBLE : View.GONE);
        }

        manager.updateAppWidget(widgetId, views);
    }
}
