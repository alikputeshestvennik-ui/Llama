#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <mutex>

// Neural Qwen core via llama.cpp. Everything is compiled only when
// BLACKBOX_WITH_LLAMA is defined; otherwise JNI stubs report unavailability
// and Java falls back to the built-in template engine.
#ifdef BLACKBOX_WITH_LLAMA
#include "llama.h"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,"BlackboxLLM",__VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"BlackboxLLM",__VA_ARGS__)
#endif

static std::mutex g_llm_mutex;
static std::string g_model_path;

#ifdef BLACKBOX_WITH_LLAMA
static llama_model*  g_model = nullptr;
static llama_context* g_ctx  = nullptr;
#endif

extern "C" JNIEXPORT jint JNICALL
Java_com_blackbox_offline_LlmEngine_nativePing(JNIEnv*, jclass) {
#ifdef BLACKBOX_WITH_LLAMA
    return 1;
#else
    return 0;
#endif
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_blackbox_offline_LlmEngine_nativeGenerate(JNIEnv *env, jclass,
        jstring jModel, jstring jPrompt, jint maxTokens, jfloat temp) {
#ifndef BLACKBOX_WITH_LLAMA
    (void)env; (void)jModel; (void)jPrompt; (void)maxTokens; (void)temp;
    return env->NewStringUTF("LLM-недоступен: llama.cpp не подключён при сборке");
#else
    const char* mp = env->GetStringUTFChars(jModel, nullptr);
    const char* pp = env->GetStringUTFChars(jPrompt, nullptr);
    std::string modelPath(mp), prompt(pp);
    env->ReleaseStringUTFChars(jModel, mp);
    env->ReleaseStringUTFChars(jPrompt, pp);

    std::lock_guard<std::mutex> lock(g_llm_mutex);

    if (g_model == nullptr || g_model_path != modelPath) {
        llama_backend_init();
        llama_model_params mparams = llama_model_default_params();
        mparams.n_gpu_layers = 0; // чистый CPU, офлайн
        llama_model* m = llama_model_load_from_file(modelPath.c_str(), mparams);
        if (m == nullptr) return env->NewStringUTF("LLM-ошибка: не удалось загрузить qwen.gguf");
        llama_context_params cparams = llama_context_default_params();
        cparams.n_ctx = 2048;
        cparams.n_batch = 512;
        cparams.n_threads = 4;
        cparams.n_threads_batch = 4;
        llama_context* ctx = llama_new_context_with_model(m, cparams);
        if (ctx == nullptr) { llama_model_free(m); return env->NewStringUTF("LLM-ошибка: не удалось создать контекст"); }
        if (g_ctx != nullptr) llama_free(g_ctx);
        if (g_model != nullptr) llama_model_free(g_model);
        g_model = m; g_ctx = ctx; g_model_path = modelPath;
        LOGI("llama model loaded: %s", modelPath.c_str());
    }

    const llama_vocab* vocab = llama_model_get_vocab(g_model);

    // Qwen2.5 chat template
    std::string full =
        "<|im_start|>system\n"
        "Ты — Blackbox, локальный автономный ассистент личного дневника. "
        "Отвечай кратко: 1-3 предложения, только по фактам из контекста, на русском. "
        "Если данных в контексте нет — честно скажи об этом.<|im_end|>\n"
        "<|im_start|>user\n" + prompt + "<|im_end|>\n"
        "<|im_start|>assistant\n";

    std::vector<llama_token> tokens(4096);
    int n = llama_tokenize(vocab, full.c_str(), (int)full.size(),
                           tokens.data(), (int)tokens.size(), true, true);
    if (n < 0) n = llama_tokenize(vocab, full.c_str(), (int)full.size(),
                                  tokens.data(), (int)tokens.size(), true, false);
    if (n <= 0) return env->NewStringUTF("LLM-ошибка: не удалось разобрать промпт");
    tokens.resize(n);

    llama_kv_cache_clear(g_ctx);

    for (int i = 0; i < n; i += 512) {
        int chunk = n - i < 512 ? n - i : 512;
        llama_batch batch = llama_batch_get_one(tokens.data() + i, chunk);
        if (llama_decode(g_ctx, batch) != 0) return env->NewStringUTF("LLM-ошибка: сбой декодирования промпта");
    }

    llama_sampler* chain = nullptr;
    if (temp <= 0.0f) {
        chain = llama_sampler_chain_init(llama_sampler_chain_default_params());
        llama_sampler_chain_add(chain, llama_sampler_init_greedy());
    } else {
        chain = llama_sampler_chain_init(llama_sampler_chain_default_params());
        llama_sampler_chain_add(chain, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(chain, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(chain, llama_sampler_init_dist(42));
    }

    std::string out;
    const llama_token eos = llama_vocab_eos(vocab);
    const int limit = maxTokens > 0 ? maxTokens : 300;
    for (int i = 0; i < limit; i++) {
        llama_token tok = llama_sampler_sample(chain, g_ctx, -1);
        if (tok == eos) break;
        char buf[256];
        int len = llama_token_to_piece(vocab, tok, buf, sizeof(buf), 0);
        if (len > 0) out.append(buf, len);
        llama_sampler_accept(chain, tok);
        if (llama_decode(g_ctx, llama_batch_get_one(&tok, 1)) != 0) break;
    }
    llama_sampler_free(chain);
    llama_kv_cache_clear(g_ctx);
    if (out.empty()) return env->NewStringUTF("LLM-ошибка: пустой ответ модели");
    return env->NewStringUTF(out.c_str());
#endif
}
