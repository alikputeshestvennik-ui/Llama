#include <jni.h>
#include <android/log.h>
#include <string>
#include <thread>
#include <mutex>
#include "whisper.h"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"BlackboxAI",__VA_ARGS__)

// Whisper context is cached for the whole app lifetime: reloading a ~1.5 GB
// model from storage before every clip froze the single transcription queue.
static std::mutex g_mutex;
static whisper_context* g_ctx = nullptr;
static std::string g_model_path;

extern "C" JNIEXPORT jstring JNICALL
Java_com_blackbox_offline_LocalAiEngine_nativeTranscribePcm(JNIEnv *env,jobject,jfloatArray pcm,jstring modelPath){
    const char *path=env->GetStringUTFChars(modelPath,nullptr);
    std::string model(path);
    env->ReleaseStringUTFChars(modelPath,path);

    std::lock_guard<std::mutex> lock(g_mutex);

    if(!g_ctx || g_model_path != model){
        if(g_ctx){ whisper_free(g_ctx); g_ctx=nullptr; }
        whisper_context_params cp=whisper_context_default_params(); cp.use_gpu=false;
        g_ctx=whisper_init_from_file_with_params(model.c_str(),cp);
        g_model_path = model;
    }
    if(!g_ctx)return env->NewStringUTF("Ошибка: не удалось открыть Whisper-модель.");

    jsize n=env->GetArrayLength(pcm);
    jfloat *audio=env->GetFloatArrayElements(pcm,nullptr);
    whisper_full_params p=whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.print_progress=false;p.print_realtime=false;p.print_timestamps=false;
    p.translate=false;p.language="ru";p.no_timestamps=true;
    unsigned int hc=std::thread::hardware_concurrency();
    p.n_threads = hc>=4 ? 4 : (hc>0 ? hc : 1);
    int rc=whisper_full(g_ctx,p,audio,n);
    env->ReleaseFloatArrayElements(pcm,audio,JNI_ABORT);
    if(rc!=0){return env->NewStringUTF("Ошибка: Whisper не смог обработать запись.");}
    std::string result;
    for(int i=0;i<whisper_full_n_segments(g_ctx);i++){const char *s=whisper_full_get_segment_text(g_ctx,i);if(s)result+=s;}
    if(result.empty())result="[Речь не распознана]";
    return env->NewStringUTF(result.c_str());
}
