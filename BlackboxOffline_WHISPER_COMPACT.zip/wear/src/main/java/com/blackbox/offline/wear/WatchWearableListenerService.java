package com.blackbox.offline.wear;

import android.content.Intent;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;
import java.nio.charset.StandardCharsets;

public class WatchWearableListenerService extends WearableListenerService {
    public static final String ACTION_PHONE_STATE = "com.blackbox.offline.wear.PHONE_STATE";
    public static final String ACTION_TRANSCRIPT_RESULT = "com.blackbox.offline.wear.TRANSCRIPT_RESULT";

    public static final String PATH_PHONE_STATUS = "/blackbox/phone_status";
    public static final String PATH_RESULT_STATUS = "/blackbox/result_status";

    @Override
    public void onMessageReceived(MessageEvent messageEvent) {
        String path = messageEvent.getPath();
        byte[] data = messageEvent.getData();
        String content = data != null ? new String(data, StandardCharsets.UTF_8) : "";

        if (PATH_PHONE_STATUS.equals(path)) {
            boolean isPhoneActive = "RECORDING".equalsIgnoreCase(content);
            Intent intent = new Intent(ACTION_PHONE_STATE);
            intent.putExtra("active", isPhoneActive);
            sendBroadcast(intent);
        } else if (PATH_RESULT_STATUS.equals(path)) {
            Intent intent = new Intent(ACTION_TRANSCRIPT_RESULT);
            intent.putExtra("message", content);
            sendBroadcast(intent);
        }
    }
}
